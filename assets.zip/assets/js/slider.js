

  var swiper = new Swiper(".sliderHome", {
      
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      });



